---
name: Druk Heritage
colors:
  surface: '#fff8f5'
  surface-dim: '#ead6c9'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e8'
  surface-container: '#feeadd'
  surface-container-high: '#f9e4d7'
  surface-container-highest: '#f3dfd2'
  on-surface: '#241a12'
  on-surface-variant: '#574141'
  inverse-surface: '#3a2e25'
  inverse-on-surface: '#ffede2'
  outline: '#8a7170'
  outline-variant: '#debfbe'
  surface-tint: '#a6373d'
  primary: '#59000e'
  on-primary: '#ffffff'
  primary-container: '#7a1620'
  on-primary-container: '#ff8586'
  inverse-primary: '#ffb3b2'
  secondary: '#805600'
  on-secondary: '#ffffff'
  secondary-container: '#ffb21d'
  on-secondary-container: '#6b4800'
  tertiary: '#002f20'
  on-tertiary: '#ffffff'
  tertiary-container: '#004832'
  on-tertiary-container: '#70b897'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b2'
  on-primary-fixed: '#410008'
  on-primary-fixed-variant: '#862028'
  secondary-fixed: '#ffddaf'
  secondary-fixed-dim: '#ffba44'
  on-secondary-fixed: '#281800'
  on-secondary-fixed-variant: '#614000'
  tertiary-fixed: '#a8f2ce'
  tertiary-fixed-dim: '#8cd5b3'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#005139'
  background: '#fff8f5'
  on-background: '#241a12'
  surface-variant: '#f3dfd2'
  maroon-deep: '#5A0E16'
  marigold: '#E2680B'
  gold-accent: '#C9A227'
  lapis: '#1D4E89'
  parchment-bg: '#FBF4E6'
  cream-card: '#FFFDF7'
  soft-ink: '#5A4D40'
  hairline: '#E7DCC4'
typography:
  display-lg:
    fontFamily: Poppins
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Poppins
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Poppins
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: Poppins
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Sintony
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Sintony
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Sintony
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Sintony
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  xxl: 64px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The design system is rooted in the rich visual tapestry of Bhutanese culture, blending the spiritual and the communal. It evokes a "warm home" atmosphere that is both culturally authentic and professionally modern. The style is **Tactile / Modern**, utilizing parchment-like textures, subtle SVG patterns (such as the endless knot and *kemar* bands), and a color palette inspired by monastic robes and Himalayan landscapes. It balances traditional stone-carved aesthetics with clean, functional layouts suitable for a high-end family dining experience.

The personality is welcoming, dependable, and steeped in heritage, targeting an audience that appreciates both culinary authenticity and contemporary ease-of-use.

## Colors

This color system is built on a "Parchment" foundation to avoid the sterile feel of pure white. 

- **Primary (Maroon):** Used for key branding, primary actions, and major headings. It represents the traditional robes of Bhutan.
- **Secondary (Saffron):** Used for highlights, active states, and "Special" menu badges.
- **Tertiary (Jade):** Used sparingly for cultural motifs, vegetarian indicators, or secondary accents to provide a cooling contrast to the warm reds and golds.
- **Neutral (Ink):** A warm, dark brown-black used for typography to maintain a softer, organic feel than pure black.

All color combinations for text and meaningful UI elements must meet WCAG 2.1 AA contrast requirements against the parchment and cream backgrounds.

## Typography

The typography strategy pairs the contemporary, friendly geometric construction of **Poppins** for headlines with the highly legible, grounded character of **Sintony** for body and UI elements.

- **Headings:** Use Poppins (Medium/Semi-Bold) for a professional yet welcoming look. Display sizes should utilize tighter letter-spacing for a modern "editorial" feel.
- **Body:** Sintony provides excellent readability for menu descriptions and long-form "Our Story" content.
- **Pricing & Labels:** Use Sintony Bold with increased letter-spacing for uppercase labels (e.g., category tags, price points) to create a distinct hierarchy from descriptive text.

## Layout & Spacing

The design system employs a **Fluid Grid** model with fixed maximum constraints for desktop readability. 

- **Grid:** Use a 12-column grid for desktop (max-width 1280px) and a 4-column grid for mobile.
- **Rhythm:** An 8px linear scale (with a 4px half-step for tight UI elements) governs all padding and margins. 
- **Section Spacing:** Generous vertical breathing room (`xxl`) is used between homepage sections to emphasize the "Cultural Story" and "Hero" visuals.
- **Mobile Adaptations:** Margins reduce to 16px on mobile devices. Card-based layouts reflow from multi-column to single-stack vertically.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Ambient Shadows**.

- **Surfaces:** The primary background is `parchment-bg`. Interactive containers (cards, modals) use `cream-card` to create a subtle lift.
- **Shadows:** Use soft, warm-tinted shadows (using a low-opacity `maroon-deep` or `soft-ink` tint) rather than neutral grays. This maintains the "warmth" of the brand.
- **Dividers:** Use the `hairline` color for subtle separation, or decorative SVG *kemar* bands for thematic section breaks.
- **Interactive Depth:** On hover, cards should transition to a slightly deeper shadow and a subtle upward shift (2px) to signify interactivity.

## Shapes

The shape language is "Rounded," balancing the geometric nature of Bhutanese art with modern UI approachability.

- **Buttons:** Use `rounded-sm` (8px) for a sturdy, traditional feel that aligns with the "stone-carved" narrative.
- **Cards & Modals:** Use `rounded-lg` (12px) to soften the appearance of large content blocks.
- **Inputs:** Match the button radius (8px) for visual consistency across forms.
- **Decorative Elements:** Circular crops for featured images (like Momos) are encouraged to mimic traditional serving plates.

## Components

- **Buttons:** Primary buttons use `maroon` backgrounds with `parchment` text. Secondary buttons use `hairline` borders with `maroon` text. All buttons feature 8px corner radius.
- **Cards:** Backgrounds set to `cream-card` with 12px corner radius and a 1px `hairline` border. Apply a soft, warm shadow.
- **Chips (Dietary Icons):** Small, `rounded-pill` shapes. Use `tertiary` (Jade) for Vegetarian (V) and `marigold` for Spicy levels.
- **Input Fields:** 8px radius, `parchment-bg` fill with a `hairline` border. Focus state uses a 2px `secondary` (Saffron) ring.
- **Lists:** Menu items should be structured with `headline-md` for names, `body-md` for descriptions in `soft-ink`, and `label-lg` for prices in `primary`.
- **Navigation:** A sticky header with a `parchment-bg` and a subtle `hairline` bottom border. The "Order Online" CTA is the most prominent element in the top-right.